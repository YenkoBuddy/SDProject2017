<?php
	require_once "connection.php"; 

if (isset($_POST['btnAssign']))
{
	$taxi = $_POST['taxi'];
	$driver = $_POST['driver'];

	if(isset($_POST['taxi']) AND isset($_POST['driver']))
	{
		$query="INSERT INTO taxi_driver(RegNo, DriverID)
				VALUES (:taxi, :driver)";
		$statement =$conn->prepare($query);
		$statement->bindParam(':taxi', $taxi);
		$statement->bindParam(':driver', $driver);
		$statement->execute();
		if ($statement)
		{
			$successMSG = "New record succesfully inserted";
		}
		else
		{
			$successMSG = "Welele";
			print_r($statement->errorCode());
        	print_r($statement->errorInfo());
		}
	}

	/*if(isset($_POST['driver']))
	{
		$query="INSERT INTO taxi-driver(RegNo, DriverID)
				VALUES (:taxi, :driver)";
		$statement =$conn->prepare($query);
		$statement->bindParam(':taxi', $taxi);
		$statement->bindParam(':driver', $driver);
		if ($statement->execute())
		{
			$successMSG = "New record succesfully inserted";
		}
	}*/
}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Assign Taxi</title>
</head>
<body>
<form method="post">

<h1><b>Assign Taxi </b></h1>
<table>
	<tr>
	<td>
	<select name="taxi">
		<option>-- Select Taxi --</option>
		<?php 
			$sql="SELECT * FROM taxi";
			$statement = $conn->prepare($sql);
			$statement->execute();
			while ($row=$statement->fetch(PDO::FETCH_ASSOC)) 
			{
		?>
				<option value="<?php echo $row['RegNo']; ?>"><?php echo $row['RegNo'], " " ,$row['Type']; ?>
				</option>
		<?php
			}
		?>	

	</select> 
	</td>	
		<td> --- </td>	
	<td>	 
	<select name="driver">
		<option>-- Select Driver --</option>
		<?php 
			$sql="SELECT * FROM driver";
			$statement = $conn->prepare($sql);
			$statement->execute();
			while ($row=$statement->fetch(PDO::FETCH_ASSOC)) 
			{
		?>
				<option value="<?php echo $row['DriverID']; ?>"><?php echo $row['FirstName'], " " ,$row['LastName']; ?>					
				</option>
		<?php
			}
		?>			
	</td>
	</select>
	</tr>
	<tr>
	<td ><input type="submit" name="btnAssign" value="Assign"></td>
	</tr>
</table>



</form>
<?php if(isset($successMSG)){ ?>
            <span><?php echo $successMSG; ?></span>
<?php } ?>
</body>
</html>