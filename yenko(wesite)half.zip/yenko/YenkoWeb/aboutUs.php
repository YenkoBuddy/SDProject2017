<!DOCTYPE html>
<html>
    <head>
    	<title>Registration Site</title>
    	<link href="css/style.css" rel="stylesheet">
    </head>
	<body>
		<div id="header"><?php include('header.php');?></div>
			<div id="content">
				<div id="about">
					<h1>Our Mission</h1>
					<p>To restore safety in the Taxi Industry.</p>					
					<h1>About Us</h1>
					<p>Yenko means “Let’s Go” in Twi which is a Ghanaian language.<br/>
					
					The aim of Yenko Buddy is to ensure the safety of passengers by availing a platform for them to <br/>
					report reckless driving and emergencies.
					All roadworthy taxis and taxi drivers are registered on Yenko Buddy to aid the tracking down of taxi <br/>
					drivers who are at fault. <br/><br/>
					We the developers of the system take taxis frequently and know firsthand, how Taxi Drivers drive <br/>
					where they shouldn't, overtake on a solid line or leave passengers stranded after not taking them <br/>
					to their desired destination. A few passengers report these incidences to the Rank Manager but <br/>
					most of it goes unpunished, so we are creating a communication medium between the Passengers <br/>
					and Taxi Association. <br/><br/>
					We aim to rid the industry of drivers who do not adhere to the road rules or taxis that are <br/>
					not roadworthy. 
					</p>
				</div>
			</div>
		<div id="footer"><?php include_once('footer.php');?></div>
	</body>
</html>