<!DOCTYPE html>
<html>
<head>
	<title>Check Details</title>
</head>
<body>
<div id="header"><?php include('header.php');?></div>
<h1><b> Check details </b></h1>

<table>
	<tr>
		<td> <img src="owner.PNG" style="width:304px;height:228px;" border="1"></td>
		<td> <img src="driver.PNG" style="width:304px;height:228px;" border="1"></td>
	</tr>
	<tr>
		<td> <input type="button" name="btnDetails" value="Personal Details"></td>
		<td> <input type="button" name="btnDetailsDriver" value="Driver Details"></td>
	</tr>
	
</table>
<div id="footer"><?php include_once('footer.php');?></div>
</body>
</html>