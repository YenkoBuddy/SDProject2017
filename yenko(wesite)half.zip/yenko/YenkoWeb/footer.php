<!DOCTYPE html>
<html>
	<head>
	</head>
	<body>
		<footer>
				<?php
					echo "<p>© 2017 January - " . date("M") . " Yenko Buddy. All Rights Reserved.</p>";
				?>
		</footer>	
	</body>
</html>
