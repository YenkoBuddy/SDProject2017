<?php
	session_start();
    $_SESSION['Empty'] = 'Empty';
    session_destroy();
?>

<!DOCTYPE html>
<html>
    <head>
    	<meta charset="utf-8">
		<meta name="viewport" content="width=device-width">
    	<title>Yenko Web design | Welcome</title>
    <!--	<link rel="stylesheet" href="mainstyle.css"> -->
    </head>
    <script type="text/javascript">

	$(document).ready(function()
	{
		$(".province").change(function()
		{
			var id=$(this).val();
			var dataString ='id='+ id;

			$.ajax
			({
				type: "POST",
				url: "getAddress.php",
				data: dataString,
				cache: false,
				success: function(html)
				{
					$(".city").html(html);
				}
			});
		});

		$(".city").change(function()
		{
			var cID=$(this).val();
			var dataString ='cID='+ cID;
			$.ajax
			({
				type: "POST",
				url: "getAddress.php",
				data: dataString,
				cache: false,
				success: function(html)
				{
					$(".suburb").html(html);
				}
			});
		});
	});
	
	
</script>
	<body>
	<!--	<div class="container">
			 <?php include('header.php');?>
		</div>
	
	<!--  New Header without include	-->
	<div class="container">
		
	<div id="branding">
		<h1><span class="highlight"> Yenko </span>Web Design </h1> <!-- span inline level element wont go on the next line-->
	</div>
	
				<nav> 
				<ul> <!--id="navigation"-->
					<li class="current"><a href="index.php">Home</a></li>
					<li><a href="contact.php">Contact</a></li>
					<li><a href="aboutUs.php">About Us</a></li>
					<li><a href="faq.php">FAQs</a></li>
					<li><a href="login.php">Login</a>
					</li>
				</ul>
			</nav>
		

	
	</div>
	
	
	
	
		<section id="showcase">
			<div>
				<h2>Yenko Buddy Aim</h2>
				<h3>
				<p>	Yenko Buddy your travel buddy, that ensures your safety when <br/> 
					commuting from point A to point B by taxi. <br/>
					Passenger? <br/>					
					Click the link below to download the mobile application:<br/>
					Download for free: &nbsp;
					<span><a href="www.yenkomate.com" class="btn">www.yenkobuddy.co.za/download</a>
					</span>
				</p>
				</h3>
			</div>
		</section>
		
		<section id="boxes">	
			<div class="container">
				<form method="POST" action="adminlogin.php">
					<div class="box">
					<img src="./images/1.JPG">
					<h2>System Clerk</h2>
					<p>Approve applications <br/> 
					   (registrations) <br/>
                       View registered owners, <br/>
					   taxis and drivers.</p>
				<!--	<button type="button" onclick="window.location.href=('adminlogin.php')">Association</button> -->
					</div>
				</form>
				<form method="POST" action="login">
					<div class="box">
					<img src="./images/1.JPG">
					<h2>Owner</h2>
					<p>Registered their taxi’s and driver. <br/>
					   Keep tabs on taxi and driver <br/>
					   information <br/>
					   and what’s needed from owner.</p>
				<!--	<button type="button" onclick="window.location.href=('login.php')">Owner</button> -->
					</div>
				</form>
				<form method="POST" action="adminlogin">
					<div class="box">
					<img src="./images/1.JPG">
					<h2>Association Administrator</h2>
					<p>Associations registration, <br/> 
					   modification <br/>
					   and viewing of details.</p>
					</div>
				<!--	<button type="button" onclick="window.location.href=('adminlogin.php')">System Admin</button> -->
				</form>
			</div>
		</section>
	
		<div id="footer"><?php include_once('footer.php');?></div>
	</body>
</html>