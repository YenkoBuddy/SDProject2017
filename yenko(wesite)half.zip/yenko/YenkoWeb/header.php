<!DOCTYPE html>
<html>
<head></head>
<body>

<header>
	<div id="logo">
			<img src="./images/Logo.png" alt="Logo" width="150px" height="100px" align="left">
			</div>
	<div class="container">		
		<div id="branding">
			
		</div>
	
	<nav>
		<ul>
			<li class="current"><a href="index.html">Home</a></li>
			<li><a href="aboutUs.php">About Us</a></li>
			<li><a href="faq.php">FAQs</a></li>
			<li><a href="login.php">Login</a></li>
			<li><a href="contact.php">Contact</a></li>
			<li><a href="email.php">Email</a></li>
		</ul>

	</nav>
	</div>
	
</header>



</body>