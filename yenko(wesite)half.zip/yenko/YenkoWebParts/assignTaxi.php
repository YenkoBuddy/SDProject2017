<!DOCTYPE html>
<html>
<head>
	<title>Assign Taxi</title>
</head>
<body>

<h1><b>Assign Taxi </b></h1>
<table>
	<tr>
	<td>
	<select name="taxi">
		<option>-- Select Taxi --</option>		
	</select> 
	</td>	
		<td> --- </td>	
	<td>	 
	<select name="driver">
		<option>-- Select Driver --</option>		
	</td>
	</select>
	</tr>
	<tr>
	<td ><input type="button" name="btnAssign" value="Assign"></td>
	</tr>
</table>

</body>
</html>